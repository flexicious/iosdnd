
#import "FLXSElasticContainer.h"
#import "FLXSFlexDataGrid.h"
#import "FLXSFlexDataGridBodyContainer.h"
#import "UIView+UIViewAdditions.h"
#import "UIScrollView+UIScrollViewAdditions.h"
#import "FLXSFlexDataGridDataCell.h"

@implementation FLXSElasticContainer {

}


@synthesize boundContainer = _boundContainer;
@synthesize grid ;
@synthesize backgroundForFillerRows = _backgroundForFillerRows;


-(id)initWithGrid:(FLXSFlexDataGrid*)gridIn
{
	self = [super init];
	if (self)
	{
		FLXSGridBackground * bg = [[FLXSGridBackground alloc] init];
        self.backgroundForFillerRows = bg;
		self.grid=gridIn;
        if(self.grid.enableFillerRows)
        {
            [self addSubview:self.backgroundForFillerRows];
            [self sendSubviewToBack:self.backgroundForFillerRows];
        }
        self.backgroundColor = self.grid.backgroundColor;
        self.delegate = self;

    }
	return self;
}
- (void)didMoveToSuperview{
    [super didMoveToSuperview];
    if(self.grid.enableDrag){
        _dropInteraction= [[UIDropInteraction alloc] initWithDelegate:self];
        [self addInteraction:_dropInteraction];
    }
    if(self.grid.enableDrop){
        _dragInteraction= [[UIDragInteraction alloc] initWithDelegate:self];
        _dragInteraction.enabled = true;
        [self addInteraction:_dragInteraction];
    }
}
-(void)setBackgroundFillerSize
{
	float ht=self.height-self.grid.bodyContainer.calculatedTotalHeight;
	if(ht<0)ht=0;
	self.backgroundForFillerRows.height=(ht);
	self.backgroundForFillerRows.width=(self.width);
	if(ht>0)
	{
        [self.backgroundForFillerRows moveToX:0 y:self.grid.bodyContainer.calculatedTotalHeight];
	}
}
-(CGSize)contentSize {
    return CGSizeMake(self.width, self.boundContainer.contentSize.height);
}


- (NSArray<UIDragItem *> *)dragInteraction:(UIDragInteraction *)interaction itemsForBeginningSession:(id<UIDragSession>)session {
    return [self.grid.bodyContainer dragInteraction:interaction itemsForBeginningSession:session];
}

- (void)dragInteraction:(UIDragInteraction *)interaction session:(id<UIDragSession>)session didEndWithOperation:(UIDropOperation)operation{
    
    [self.grid.bodyContainer dragInteraction:interaction session:session didEndWithOperation:operation];
}

- (void)dragInteraction:(UIDragInteraction *)interaction item:(UIDragItem *)item willAnimateCancelWithAnimator:(id<UIDragAnimating>)animator{
    [self.grid.bodyContainer dragInteraction:interaction item:item willAnimateCancelWithAnimator:animator];
}

- (UITargetedDragPreview *)dragInteraction:(UIDragInteraction *)interaction previewForLiftingItem:(UIDragItem *)item session:(id<UIDragSession>)session {
    return [self.grid.bodyContainer dragInteraction:interaction previewForLiftingItem:item session:session];
}

- (void)dragInteraction:(UIDragInteraction *)interaction sessionDidTransferItems:(id<UIDragSession>)session{
    [self.grid.bodyContainer dragInteraction:interaction sessionDidTransferItems:session];
    
}

- (void)dragInteraction:(UIDragInteraction *)interaction willAnimateLiftWithAnimator:(id<UIDragAnimating>)animator session:(id<UIDragSession>)session{
    [self.grid.bodyContainer dragInteraction:interaction willAnimateLiftWithAnimator:animator session:session];
}

- (UIDropProposal *)dropInteraction:(UIDropInteraction *)interaction sessionDidUpdate:(id<UIDropSession>)session {
    return [self.grid.bodyContainer dropInteraction:interaction sessionDidUpdate:session];
}

- (void)dropInteraction:(UIDropInteraction *)interaction sessionDidExit:(id<UIDropSession>)session{
    [self.grid.bodyContainer dropInteraction:interaction sessionDidExit:session];
}

- (void)dropInteraction:(UIDropInteraction *)interaction performDrop:(id<UIDropSession>)session {
    [self.grid.bodyContainer dropInteraction:interaction performDrop:session];
}

- (BOOL)dropInteraction:(UIDropInteraction *)interaction canHandleSession:(id<UIDropSession>)session {
    return [self.grid.bodyContainer dropInteraction:interaction canHandleSession:session];
}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if(self.grid.enableDrop)
    self.grid.bodyContainer.verticalScrollPosition = self.verticalScrollPosition;
}   
@end

