#import "FLXSLevelSelectionInfo.h"


@implementation FLXSLevelSelectionInfo

@synthesize levelNestDepth;
@synthesize selectedObjects;
@synthesize excludedObjects;


@end

