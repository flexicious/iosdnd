#import "FLXSComponentAdditionResult.h"


@implementation FLXSComponentAdditionResult

@synthesize horizontalSpill;
@synthesize verticalSpill;
@synthesize componentInfo;


@end

