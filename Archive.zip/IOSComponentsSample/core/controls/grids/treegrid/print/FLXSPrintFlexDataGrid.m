//#import "FLXSPrintFlexDataGrid.h"
//
//
//@implementation FLXSPrintFlexDataGrid
//
//@synthesize printWindow;
//@synthesize totalPagesHeight;
//
//-(id)init
//{
//    //next version
////	self = [super init];
////	if (self)
////	{
////		allowInteractivity=NO;
////	}
////	return self;
//    return nil;
//}
//
//
//-(FLXSFlexDataGridBodyContainer*)createBodyContainer
//{
//    //next version
////	return [[PrintFLXSFlexDataGridBodyContainer alloc] init:self];
//    return nil;
//}
//
//-(NSArray*)printListItems
//{
//    //next version
////	return [nil];
//    return nil;
//}
//
//-(void)setResizableColumns:(BOOL)val
//{
//}
//
//-(BOOL)validNextPage
//{
//    //next version
////	return bodyContainer.validNextPage;
//    return NO;
//}
//
//-(void)nextPage
//{
//	//next version
////    [bodyContainer nextPage];
////	[self synchronizeLockedVerticalScroll];
//}
//
//-(void)placeComponents:(FLXSRowInfo*)row
//{
//	//next version
////    [self placeChildComponents:row.cells];
//}
//
//-(void)showPositions:(NSArray*)positions
//{
//}
//
//-(float)headerHeight
//{
//    //next version
////	return headerSectionHeight;
//    return 0;
//}
//
//-(BOOL)enableHeightAutoAdjust
//{
//	return NO;
//}
//
//@end
//
