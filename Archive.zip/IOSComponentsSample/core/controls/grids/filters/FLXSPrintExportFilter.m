#import "FLXSPrintExportFilter.h"

@implementation FLXSPrintExportFilter

@synthesize printExportOptions;


@end
