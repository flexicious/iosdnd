//
// Created by FLEXICIOUS-MAC on 7/19/13.
// Copyright (c) 2013 ___IOSComponents___. All rights reserved.
//
// To change the template use AppCode | Preferences | File Templates.
//


#import "FLXSVersion.h"


@implementation FLXSVersion {

}
@end