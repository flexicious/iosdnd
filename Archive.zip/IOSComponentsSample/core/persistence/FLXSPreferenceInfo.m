#import "FLXSPreferenceInfo.h"


@implementation FLXSPreferenceInfo

@synthesize name;
@synthesize isSystemPref;
@synthesize preferences;



@end

