//#import "FLXSPrintPreviewEvent.h"
//
//static NSString * PAGE_INDEX_CHANGED = @"pageIndexChanged";
//
//static NSString * COLUMNS_CHANGED = @"columnsChanged";
//static NSString * DATAGRID_RECREATE_REQUIRED = @"gridRecreateRequired";
//static NSString * COLUMNS_RESIZED = @"gridColumnsResized";
//static NSString * PAGE_OPTIONS_CHANGED = @"pageOptionsChanged";
//static NSString * PRINT_REQUESTED = @"printRequested";
//static NSString * PDF_BYTES_READY = @"pdfBytesReady";
//static NSString * BEFORE_PRINT = @"beforePrint";
//static NSString * PRINT_JOB_CREATED = @"printJobCreated";
//static NSString * AFTER_PRINT = @"afterPrint";
//
//@implementation FLXSPrintPreviewEvent
//
//@synthesize printOptions;
//
//+ (NSString*)PAGE_INDEX_CHANGED
//{
//	return PAGE_INDEX_CHANGED;
//}
//+ (NSString*)COLUMNS_CHANGED
//{
//	return COLUMNS_CHANGED;
//}
//+ (NSString*)DATAGRID_RECREATE_REQUIRED
//{
//	return DATAGRID_RECREATE_REQUIRED;
//}
//+ (NSString*)COLUMNS_RESIZED
//{
//	return COLUMNS_RESIZED;
//}
//+ (NSString*)PAGE_OPTIONS_CHANGED
//{
//	return PAGE_OPTIONS_CHANGED;
//}
//+ (NSString*)PRINT_REQUESTED
//{
//	return PRINT_REQUESTED;
//}
//+ (NSString*)PDF_BYTES_READY
//{
//	return PDF_BYTES_READY;
//}
//+ (NSString*)BEFORE_PRINT
//{
//	return BEFORE_PRINT;
//}
//+ (NSString*)PRINT_JOB_CREATED
//{
//	return PRINT_JOB_CREATED;
//}
//+ (NSString*)AFTER_PRINT
//{
//	return AFTER_PRINT;
//}
//@end
//
