# iOSDataGrid


iOS DataGrid - The most powerful DataGrid component for iOS. Support inline filters, summary footers, server/client paging, excel/ word export, user settings persistence, hierarchical tree/child grids, left/right locked columns, lazy load and more!
# Screenshots/Demo:
http://www.ioscomponents.com/Home/IOSDataGrid

# Docs:
http://ioscomponents.com/Home/Docs

# Professional Support:
We offer professional support and training around our products:
http://ioscomponents.com/Home/Buy

# Consulting Services:
We offer consulting services, including iOS App development, and integration with iOS DataGrid with your apps:
http://ioscomponents.com/Home/iOSConsulting
