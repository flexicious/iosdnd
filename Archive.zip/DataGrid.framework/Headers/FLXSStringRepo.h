#import "FLXSVersion.h"
@interface FLXSStringRepo : NSObject
{
}

+ (NSString*)AUTO_REFRESH;
+ (NSString*)AUTO_REFRESH_LAST_UPDATED_ON;
+ (NSString*)AUTO_REFRESH_DATE_FRMT;
@end

