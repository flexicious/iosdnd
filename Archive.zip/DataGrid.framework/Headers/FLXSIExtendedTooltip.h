#import "FLXSVersion.h"
@protocol FLXSIExtendedTooltip
-(UIView*)tooltipOwner;
-(void)tooltipOwner:(UIView*)val;
@end

