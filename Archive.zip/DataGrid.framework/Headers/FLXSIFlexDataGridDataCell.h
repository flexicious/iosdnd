#import "FLXSVersion.h"
#import "FLXSIFlexDataGridCell.h"

@protocol FLXSIFlexDataGridDataCell<FLXSIFlexDataGridCell>

@property (nonatomic, assign) int colSpan;
@property (nonatomic, assign) int rowSpan;

@end

