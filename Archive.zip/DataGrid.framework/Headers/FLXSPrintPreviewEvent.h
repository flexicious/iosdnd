//#import "FLXSVersion.h"
//#import "FLXSEvent.h"
//
//@class FLXSPrintOptions;
//
//@interface FLXSPrintPreviewEvent : FLXSEvent
//{
//
//}
//
//@property (nonatomic, weak) FLXSPrintOptions* printOptions;
//
//- (id)initWithType:(NSString *)type andBubbles:(BOOL)bubbles andCancelable:(BOOL)cancelable;
//
//+ (NSString*)PAGE_INDEX_CHANGED;
//+ (NSString*)COLUMNS_CHANGED;
//+ (NSString*)DATAGRID_RECREATE_REQUIRED;
//+ (NSString*)COLUMNS_RESIZED;
//+ (NSString*)PAGE_OPTIONS_CHANGED;
//+ (NSString*)PRINT_REQUESTED;
//+ (NSString*)PDF_BYTES_READY;
//+ (NSString*)BEFORE_PRINT;
//+ (NSString*)PRINT_JOB_CREATED;
//+ (NSString*)AFTER_PRINT;
//@end
//
