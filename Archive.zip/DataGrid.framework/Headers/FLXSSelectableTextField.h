#import "FLXSVersion.h"

@interface FLXSSelectableTextField : UITextField   <UITextFieldDelegate>
@end