#import "FLXSExporter.h"
#import "FLXSVersion.h"

@interface FLXSTxtExporter : FLXSExporter

@end

