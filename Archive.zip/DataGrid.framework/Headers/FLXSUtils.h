//#import "FLXSVersion.h"
//
//
//@interface FLXSUtil : NSObject
//{
//}
//
//+(NSString*)make10:(NSString*)s;
//+(NSString*)toHex:(int)n :(BOOL)bigEndian;
//+(NSString*)hash:(NSString*)s;
//@end
//
