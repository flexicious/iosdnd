//#import "FLXSVersion.h"
//@protocol FLXSIPrintable;
//@protocol FLXSIPrintComponent;
//@class FLXSPrintOptions;
//
//@protocol FLXSIPrintArea
//-(int)currentPage;
//-(void)currentPage:(int)val;
//-(void)pageRecords:(NSMutableArray*)val;
//-(NSMutableArray*)pageRecords;
//-(void)allRecords:(NSMutableArray*)val;
//-(NSMutableArray*)allRecords;
//-(int)totalPages;
//-(void)totalPages:(int)val;
//-(UIView <FLXSIPrintable>*)printable;
//-(void)printable:(UIView<FLXSIPrintable>*)val;
//-(UIView <FLXSIPrintComponent>*)printComponent;
//-(void)printComponent:(UIView <FLXSIPrintComponent>*)val;
//-(float)height;
//-(BOOL)includeInLayout;
//-(void)printOptions:(FLXSPrintOptions*)val;
//-(FLXSPrintOptions*)printOptions;
//@end
//
