//#import "FLXSVersion.h"
//@class FLXSPrintOptions;
//
//@protocol FLXSIPrintPreview
//-(UIScrollView*)content;
//-(void)printOptions:(FLXSPrintOptions*)val;
//-(FLXSPrintOptions*)printOptions;
//-(int)totalPages;
//-(void)totalPages:(int)val;
//-(int)currentPage;
//-(void)currentPage:(int)val;
//-(void)validateNow;
//-(void)progress:(NSString*)val;
//@end                    a
//
