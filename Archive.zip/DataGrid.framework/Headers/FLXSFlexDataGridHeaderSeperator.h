#import "FLXSVersion.h"
@interface FLXSFlexDataGridHeaderSeparator : UIView
{

}

@property (nonatomic, assign) BOOL resizing;

@end

