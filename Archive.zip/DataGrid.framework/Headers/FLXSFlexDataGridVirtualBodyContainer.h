#import "FLXSFlexDataGridBodyContainer.h"
#import "FLXSVersion.h"
/**
* The container for the body that supports virtual scrolling
*/
//virtual scroll to be implemented in v1.2
@interface FLXSFlexDataGridVirtualBodyContainer : FLXSFlexDataGridBodyContainer
{
}


@end

