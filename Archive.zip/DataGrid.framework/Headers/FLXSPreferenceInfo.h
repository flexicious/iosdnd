#import "FLXSVersion.h"
@interface FLXSPreferenceInfo : NSObject
{
}

@property (nonatomic, strong) NSString* name;
@property (nonatomic, assign) BOOL isSystemPref;
@property (nonatomic, strong) NSString* preferences;


@end

