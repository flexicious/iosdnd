#import "FLXSVersion.h"


@interface FLXSPoint : NSObject
{
}

@property float x;
@property float y;


-(id)initWithX:(float)xValue  andY:(float)yValue;

@end
