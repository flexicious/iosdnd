#import "FLXSVersion.h"

@interface FLXSDateTimeButton : UIButton

@property (nonatomic, retain) NSDictionary *dtAttibute;
@property UIDatePickerMode  buttonMode;

@end

