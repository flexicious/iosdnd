#import "FLXSExporter.h"
#import "FLXSVersion.h"

@protocol FLXSIExtendedDataGrid;

@interface FLXSXmlExporter : FLXSExporter

@end

