#import "FLXSVersion.h"
#import "FLXSFlexDataGridExpandCollapseCell.h"
/**
	 * @inheritDoc
	 */

@interface FLXSFlexDataGridExpandCollapseHeaderCell : FLXSFlexDataGridExpandCollapseCell

-(BOOL)drawTopBorder;
@end

