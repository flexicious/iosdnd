#import "FLXSVersion.h"


@interface FLXSChecker : NSObject
{
}

@property (nonatomic, strong) NSObject * dispatcher;
@property (nonatomic, strong) NSObject * urlReq1;

+(NSString*)licenseKey;

@end

