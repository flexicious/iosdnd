#import <UIKit/UIKit.h>

@interface FLXSVersion : NSObject
@end